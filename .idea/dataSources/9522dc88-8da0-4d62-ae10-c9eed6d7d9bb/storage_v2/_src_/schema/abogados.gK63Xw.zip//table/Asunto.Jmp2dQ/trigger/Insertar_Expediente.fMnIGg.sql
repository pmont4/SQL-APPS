create definer = root@`%` trigger Insertar_Expediente
    after insert
    on Asunto
    for each row
    INSERT INTO Expediente (IdAsunto, Fecha_Registro) VALUES (NEW.IdAsunto, NEW.Fecha_Inicio);

