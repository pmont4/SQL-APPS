create definer = root@`%` trigger POST_LIKE_TRIGGER_USER_ALREADY_LIKED
    before insert
    on POST_LIKE
    for each row
BEGIN
            DECLARE ROW_COUNT INT;

            SELECT COUNT(*) INTO ROW_COUNT
            FROM POST_LIKE PL
            WHERE PL.ID_POST = NEW.ID_POST AND PL.ID_USER = NEW.ID_USER;

            IF ROW_COUNT >= 1 THEN
                SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Already like this posts!';
            END IF;
        END;

