create definer = root@`%` view posts_information_view as
select `P`.`ID_POST`                                                                                              AS `Post ID`,
       concat(upper(left(`P`.`POST_NAME`, 1)), lower(right(`P`.`POST_NAME`, (length(`P`.`POST_NAME`) - 1))),
              '.')                                                                                                AS `Post title`,
       concat(upper(left(`P`.`POST_BODY`, 1)), lower(right(`P`.`POST_BODY`, (length(`P`.`POST_BODY`) - 1))),
              '.')                                                                                                AS `Post content`,
       `P`.`ID_USER`                                                                                              AS `User ID`,
       `BU`.`NICKNAME`                                                                                            AS `User name`,
       concat(monthname(`P`.`POST_DATE`), ' ', dayofmonth(`P`.`POST_DATE`), ', ',
              year(`P`.`POST_DATE`))                                                                              AS `Posted on`,
       ifnull((select `BU`.`NICKNAME` from `blog`.`blog_user` `BU` where (`BU`.`ID_USER` = `PC`.`ID_USER`)),
              'Not commented yet')                                                                                AS `Commented by`,
       ifnull(`PC`.`COMMENT_TEXT`, 'Not commented yet')                                                           AS `Comment body`,
       ifnull(concat(monthname(`P`.`POST_DATE`), ' ', dayofmonth(`P`.`POST_DATE`), ', ', year(`P`.`POST_DATE`)),
              'Not commented yet')                                                                                AS `Comment made on`,
       (case
            when (count(`PC`.`ID_POST`) <= 0) then 'Has no comments'
            else cast(count(`PC`.`ID_POST`) as char charset utf8mb3) end)                                         AS `Total comments in this post`,
       (case
            when (count(`PL`.`ID_POST`) <= 0) then 'Has no likes'
            else cast(count(`PL`.`ID_POST`) as char charset utf8mb3) end)                                         AS `Likes`
from (((`blog`.`post` `P` left join `blog`.`blog_user` `BU`
        on ((`P`.`ID_USER` = `BU`.`ID_USER`))) left join `blog`.`post_like` `PL`
       on ((`P`.`ID_POST` = `PL`.`ID_POST`))) left join `blog`.`post_comment` `PC`
      on ((`P`.`ID_POST` = `PC`.`ID_POST`)))
group by `P`.`ID_POST`, `P`.`POST_NAME`, `P`.`POST_BODY`, `P`.`ID_USER`, `BU`.`NICKNAME`, `P`.`POST_DATE`,
         `PC`.`ID_USER`, `PC`.`COMMENT_TEXT`, `PC`.`COMMENT_DATE`
order by count(`PL`.`ID_POST`) desc;

