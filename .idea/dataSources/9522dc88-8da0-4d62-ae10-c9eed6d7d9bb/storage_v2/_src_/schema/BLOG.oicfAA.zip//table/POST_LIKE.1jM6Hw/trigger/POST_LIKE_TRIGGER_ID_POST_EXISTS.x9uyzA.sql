create definer = root@`%` trigger POST_LIKE_TRIGGER_ID_POST_EXISTS
    before insert
    on POST_LIKE
    for each row
BEGIN
            IF NOT(EXISTS(SELECT P.ID_POST FROM POST P WHERE P.ID_POST = NEW.ID_POST)) THEN
                SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Cannot find the post in the post table!';
            END IF;
        END;

