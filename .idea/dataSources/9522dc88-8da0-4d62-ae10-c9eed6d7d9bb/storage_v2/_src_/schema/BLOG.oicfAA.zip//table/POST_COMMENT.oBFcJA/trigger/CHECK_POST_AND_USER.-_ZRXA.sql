create definer = root@`%` trigger CHECK_POST_AND_USER
    before insert
    on POST_COMMENT
    for each row
BEGIN
            IF NOT(EXISTS(SELECT BU.ID_USER FROM BLOG_USER BU WHERE BU.ID_USER = NEW.ID_USER))
                   || NOT(EXISTS(SELECT P.ID_POST FROM POST P WHERE P.ID_POST = NEW.ID_POST)) THEN
                SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'The id of the user or the id of the post does not exists in the database!';
            END IF;
        END;

