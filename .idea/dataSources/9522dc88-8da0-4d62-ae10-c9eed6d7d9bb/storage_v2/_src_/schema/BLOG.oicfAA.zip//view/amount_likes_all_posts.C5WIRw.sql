create definer = root@`%` view amount_likes_all_posts as
select `P`.`ID_POST` AS `ID_POST`, `P`.`POST_NAME` AS `POST_NAME`, count(`PL`.`ID_POST`) AS `Post likes`
from (`blog`.`post` `P` left join `blog`.`post_like` `PL` on ((`P`.`ID_POST` = `PL`.`ID_POST`)))
group by `P`.`ID_POST`;

