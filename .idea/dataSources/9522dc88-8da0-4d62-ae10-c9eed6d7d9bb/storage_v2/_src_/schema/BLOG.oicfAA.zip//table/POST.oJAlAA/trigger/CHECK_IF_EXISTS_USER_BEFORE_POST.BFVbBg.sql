create definer = root@`%` trigger CHECK_IF_EXISTS_USER_BEFORE_POST
    before insert
    on POST
    for each row
BEGIN
		IF NOT(EXISTS(SELECT BU.ID_USER FROM BLOG_USER BU WHERE BU.ID_USER = NEW.ID_USER)) THEN
            SIGNAL SQLSTATE '45000'
		    SET MESSAGE_TEXT = 'The user id was not found in the table';
        END IF;
    END;

